<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Review</title>
</head>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>THANK YOU PAGE</title>
    <link rel="stylesheet" href="../css/style.css" />
</head>

<body>
    <div class="container">
        <button type="submit" class="btn">Submit</button>
        <div class="popup">
            <img src="../images/capedalogo.png" />
            <h2><b>Thank You!</b></h2>
            <p>
                You're account is still being reviewed. You will receive an email about the status of your account. Regards
            </p>
            <button type="button">OK</button>
        </div>
    </div>
</body>

</html>