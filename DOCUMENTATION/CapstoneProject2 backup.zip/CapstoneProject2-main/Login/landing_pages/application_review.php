<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>THANK YOU PAGE</title>
    <link rel="stylesheet" href="../../css/login/style.css" />
</head>

<body>
    <div class="container">
        <div class="popup">
            <img src="../../images/capedalogo.png" />
            <h2><b>Thank You!</b></h2>
            <p>
                You're account is still being reviewed. You will receive an email about the status of your account. Regards
            </p>
            <button type="button" onclick="redirectToLogin()">OK</button>
        </div>
    </div>
    <script src="../../js/login/landing_pages_button.js"></script>
</body>


</html>