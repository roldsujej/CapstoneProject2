function redirectToLogin() {
  window.location.href = "../../logout.php"; // Replace with the actual path to your login page
}
