  <hr>
  <h3 class="modalHeader">ACCOUNT SETTINGS:</h3>
  <hr>
  <div class="form-group">
      <label class="label" for="">Email</label>
      <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" required>
  </div>
  <div class="form-group">
      <label class="label" for="">Current Password</label>
      <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" required>
  </div>
  <div class="form-group">
      <label class="label" for="">New Password</label>
      <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" required>
  </div>
  <div class="form-group">
      <label class="label" for="">Confirm Password</label>
      <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" required>
  </div>

  </div>