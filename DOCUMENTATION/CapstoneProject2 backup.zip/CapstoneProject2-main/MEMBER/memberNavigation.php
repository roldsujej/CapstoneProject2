 <div class="navigation">
     <ul>
         <li>
             <a href="">
                 <span class="icon"><ion-icon name="car-outline"></ion-icon></span>
                 <span class="title">Sample Name</span>
             </a>
         </li>
         <li>
             <a href="memberDashboard.php">
                 <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                 <span class="title">Dashboard</span>
             </a>
         </li>
         <li>
             <a href="memberAccountManagement.php">
                 <span class="icon"><ion-icon name="bar-chart-outline"></ion-icon></span>
                 <span class="title">My Account</span>

             </a>
         </li>
         <li>
             <a href="memberDocuments.php">
                 <span class="icon"><ion-icon name="people-outline"></ion-icon></span>
                 <span class="title">My Documents</span>
             </a>
         </li>

         <li>
             <a href="memberAnnouncement.php">
                 <span class="icon"><ion-icon name="alert-outline"></ion-icon></span>
                 <span class="title">Announcements</span>
             </a>
         </li>
         <li>
             <a href="">
                 <span class="icon"><ion-icon name="exit-outline"></ion-icon></span>
                 <span class="title">Log Out</span>
             </a>
         </li>
     </ul>
 </div>