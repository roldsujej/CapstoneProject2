<?php

echo "Dito mapupunta pag di pa verified";
